import sys
sys.path[:0]=['tests','third_party/DMM']
import torch
from rendering_fixtures import fixture_scene,observation
from test_rendering import triangle
from dmm.rendering import render_mesh,RenderConfig
from dmm.surface import DifferentiableMesh,SurfaceConfig
torch.set_num_threads(1)
s=fixture_scene(torch.float32).cuda()
c=SurfaceConfig(resolution=18,chunk_size=2048)
r,m,ch=s.render_views(c,RenderConfig())
q=s.arches['upper'].q['11']
for base in [0.,.137]:
 with torch.no_grad(): q[0]=base
 r,m,ch=s.render_views(c,RenderConfig())
 loss=r['front'].semantics[...,1].sum()
 print('base',base,'loss',float(loss.detach()),'ad',torch.autograd.grad(loss,q)[0].tolist(),flush=True)
 for eps in [.01,.002,.0005,.0001]:
  vals=[]
  for v in [base+eps,base-eps]:
   with torch.no_grad():q[0]=v
   rr,mm,_=s.render_views(c,RenderConfig(),ch)
   vals.append(float(rr['front'].semantics[...,1].sum().detach()))
  print(eps,vals,(vals[0]-vals[1])/(2*eps),flush=True)
t=triangle(); v=t.vertices_world_mm.detach().float().cuda().requires_grad_(); f=t.faces.cuda(); sem=t.semantics.float().cuda()
for shift in [0.,.123]:
 delta=torch.tensor(shift,device='cuda',requires_grad=True)
 def go(x):
  vv=v+torch.stack([x,x*0,x*0])[None]
  return render_mesh(DifferentiableMesh(vv,f,sem,t.face_arch.cuda(),{}),observation(),RenderConfig()).semantics[...,1].sum()
 l=go(delta); ad=torch.autograd.grad(l,delta)[0]
 print('triangle',shift,float(l.detach()),float(ad),flush=True)
 for e in [.01,.002,.0005]: print(e,float(((go(delta+e)-go(delta-e))/(2*e)).detach()),flush=True)
