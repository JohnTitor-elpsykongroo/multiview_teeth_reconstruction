import sys
sys.path[:0]=['third_party/DMM','tests']
import torch,nvdiffrast.torch as dr
from dmm.rendering import clip_coordinates,RenderConfig
from rendering_fixtures import observation
from test_rendering import triangle
torch.set_num_threads(1)
t=triangle();v=t.vertices_world_mm.detach().float().cuda();f=t.faces.int().cuda();o=observation();k=v.new_tensor(o.K)
ctx=dr.RasterizeCudaContext();direction=torch.zeros_like(v);direction[2,1]=1
for n in [1,2,29,32]:
 def go(x):
  clip=clip_coordinates(v+x*direction,k,40,40,RenderConfig())[None].contiguous()
  rast,_=dr.rasterize(ctx,clip,f,(40,40))
  hit=(rast[...,3:4]>0).float()
  colors=hit.expand(-1,-1,-1,n).contiguous()
  return dr.antialias(colors,rast,clip,f)[...,0].sum()
 q=torch.tensor(0.,device='cuda',requires_grad=True);loss=go(q);ad=torch.autograd.grad(loss,q)[0]
 print(n,float(loss.detach()),float(ad),[(e,float(((go(q+e)-go(q-e))/(2*e)).detach())) for e in [.02,.002,.0002]],flush=True)
