exec(open('.runtime/aa_probe.py').read().split('for base in')[0])
from PIL import Image
import numpy as np
from scipy.ndimage import binary_erosion
for k in range(5):
 rr=render_mesh(m,s.observations[0],RenderConfig())
 hit=rr.face_index>=0
 print(k,float(rr.semantics[...,1].sum().detach()),float(rr.coverage.sum().detach()),int(hit.sum()),flush=True)
 if k==0:
  sem=rr.semantics.detach().cpu().numpy(); cov=rr.coverage.detach().cpu().numpy()
  interior=binary_erosion(hit.cpu().numpy(),iterations=2)
  print('Interior coverage',cov[interior].min(),cov[interior].max(),flush=True)
  im=np.stack([sem[...,1],sem[...,15],cov*.25],-1)
  Image.fromarray((im.clip(0,1)*255).astype(np.uint8)).resize((400,400)).save('.runtime/aa-repeat.png')
for eps in [0,.0001,-.0001]:
 mm=DifferentiableMesh(m.vertices_world_mm+torch.tensor([eps,0,0],device='cuda'),m.faces,m.semantics,m.face_arch,{})
 rr=render_mesh(mm,s.observations[0],RenderConfig())
 print('translation',eps,float(rr.semantics[...,1].sum().detach()),float(rr.coverage.sum().detach()),int((rr.face_index>=0).sum()),flush=True)
